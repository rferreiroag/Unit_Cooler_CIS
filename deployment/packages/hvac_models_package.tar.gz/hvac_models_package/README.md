# HVAC Unit Cooler Digital Twin - Trained Models Package

**Date:** 2025-11-19
**Project:** HVAC Unit Cooler Digital Twin
**Training Date:** 2025-11-18

---

## Package Contents

### 1. Production Models (ONNX) - **RECOMMENDED FOR DEPLOYMENT**

**Location:** `deployment/onnx/`

| Model | Target | Size | Latency (P95) | Usage |
|-------|--------|------|---------------|-------|
| `lightgbm_ucaot.onnx` | Air Outlet Temp | 669 KB | 0.022 ms | Production inference |
| `lightgbm_ucwot.onnx` | Water Outlet Temp | 667 KB | 0.017 ms | Production inference |
| `lightgbm_ucaf.onnx` | Air Flow | 298 KB | 0.021 ms | Production inference |

**Total:** 1.6 MB

**Use with ONNX Runtime:**
```python
import onnxruntime as ort
import numpy as np

# Load model
session = ort.InferenceSession('deployment/onnx/lightgbm_ucaot.onnx')

# Prepare input (52 features)
X = np.random.randn(1, 52).astype(np.float32)

# Run inference
input_name = session.get_inputs()[0].name
output_name = session.get_outputs()[0].name
prediction = session.run([output_name], {input_name: X})[0]
```

### 2. Original Models (Python Pickle)

**Location:** `models/`

| Model | Size | Purpose |
|-------|------|---------|
| `lightgbm_model.pkl` | 2.2 MB | Original LightGBM (for retraining) |
| `xgboost_model.pkl` | 697 KB | XGBoost baseline comparison |

**Use with scikit-learn:**
```python
import joblib

# Load model (dict with 3 models)
models = joblib.load('models/lightgbm_model.pkl')

# Access individual models
model_ucaot = models['models']['UCAOT']
model_ucwot = models['models']['UCWOT']
model_ucaf = models['models']['UCAF']

# Make prediction
prediction = model_ucaot.predict(X_scaled)
```

### 3. Preprocessing Artifacts

**Location:** `data/processed/`

| File | Size | Purpose |
|------|------|---------|
| `scaler.pkl` | 3.3 KB | StandardScaler for features (required for inference) |
| `metadata.json` | 1.1 KB | Feature names, target names, dataset info |

**Use scaler:**
```python
import joblib
import json

# Load scaler
scaler = joblib.load('data/processed/scaler.pkl')

# Load metadata
with open('data/processed/metadata.json', 'r') as f:
    metadata = json.load(f)

# Scale features before prediction
X_scaled = scaler.transform(X_raw)
```

---

## Model Performance

### LightGBM (Production Model) ✅

| Target | R² | MAPE | MAE | P95 Latency |
|--------|-----|------|-----|-------------|
| UCAOT (Air Outlet Temp) | 0.9926 | 8.7% | 0.034°C | 0.022 ms |
| UCWOT (Water Outlet Temp) | 0.9975 | 8.7% | 0.031°C | 0.017 ms |
| UCAF (Air Flow) | 1.0000 | 0.008% | 0.0001 | 0.021 ms |

**Improvement over FMU baseline:** 93-100% ✅

### XGBoost (Alternative)

| Target | R² | MAPE |
|--------|-----|------|
| UCAOT | 0.9768 | 15.4% |
| UCWOT | 0.9940 | 14.2% |
| UCAF | 1.0000 | 0.012% |

---

## Input Features (52 total)

**Required features for inference (see `metadata.json` for complete list):**

### Raw Sensor Features (20):
- AMBT, UCTSP, CPSP, UCAIT, CPPR, UCWF, CPMC, MVDP, CPCF, UCFS
- MVCV, UCHV, CPMV, UCHC, UCWIT, UCFMS, CPDP, UCWDP, MVWF, UCOM

### Engineered Features (32):
- Temperature deltas: delta_T_water, delta_T_air, T_approach, etc.
- Thermal power: Q_water, Q_air, Q_avg, Q_imbalance, Q_imbalance_pct
- Heat exchanger: efficiency_HX, effectiveness, NTU, C_ratio
- Flow dynamics: mdot_water, mdot_air, flow_ratio, Re_air_estimate
- Control: setpoint_error, setpoint_error_abs, delta_T_ratio
- Power: P_fan_estimate, P_pump_estimate, P_total_estimate, COP_estimate
- Temporal: time_index, cycle_hour, hour_sin, hour_cos
- Interactions: T_water_x_flow, T_air_x_flow, ambient_x_inlet

**Important:** All 52 features must be provided. Use feature engineering scripts from the repository to generate engineered features from raw sensor data.

---

## Quick Start

### Option 1: ONNX Runtime (Recommended for Production)

```bash
pip install onnxruntime numpy

python -c "
import onnxruntime as ort
import numpy as np

session = ort.InferenceSession('deployment/onnx/lightgbm_ucaot.onnx')
X = np.random.randn(1, 52).astype(np.float32)
result = session.run(None, {session.get_inputs()[0].name: X})
print(f'Prediction: {result[0][0][0]:.2f}')
"
```

### Option 2: Python Pickle (For Retraining)

```bash
pip install lightgbm scikit-learn joblib

python -c "
import joblib
import numpy as np

models = joblib.load('models/lightgbm_model.pkl')
scaler = joblib.load('data/processed/scaler.pkl')

X_raw = np.random.randn(1, 52)
X_scaled = scaler.transform(X_raw)

pred_ucaot = models['models']['UCAOT'].predict(X_scaled)
pred_ucwot = models['models']['UCWOT'].predict(X_scaled)
pred_ucaf = models['models']['UCAF'].predict(X_scaled)

print(f'UCAOT: {pred_ucaot[0]:.2f}')
print(f'UCWOT: {pred_ucwot[0]:.2f}')
print(f'UCAF: {pred_ucaf[0]:.2f}')
"
```

---

## Deployment Recommendations

**For Production:**
✅ Use ONNX models (`deployment/onnx/*.onnx`)
✅ Use ONNX Runtime (fast, cross-platform, no Python dependencies)
✅ 10-100× faster than pickle
✅ Smaller memory footprint

**For Development/Retraining:**
✅ Use pickle models (`models/lightgbm_model.pkl`)
✅ Full LightGBM API available
✅ Can retrain with new data
✅ Feature importance analysis

**Always Required:**
✅ `scaler.pkl` - Must scale features before prediction
✅ `metadata.json` - Feature names and order

---

## System Requirements

**Minimum:**
- Python 3.8+
- 50 MB RAM
- CPU (no GPU needed)

**Recommended:**
- Python 3.10+
- 100 MB RAM
- Multi-core CPU (for batch inference)

**Dependencies:**
```bash
# For ONNX
pip install onnxruntime numpy

# For Pickle models
pip install lightgbm scikit-learn joblib numpy pandas

# For XGBoost
pip install xgboost
```

---

## Training Environment

**Models trained on:**
- Platform: Linux x86_64
- CPU: 16 cores
- RAM: 13 GB
- Python: 3.11.14
- Training time: <1 minute (LightGBM)

**Training dataset:**
- Samples: 43,147 (after cleaning)
- Features: 52 (engineered)
- Targets: 3 (UCAOT, UCWOT, UCAF)
- Split: 70% train / 15% val / 15% test

---

## Support

For questions or issues:
1. Check the main repository documentation
2. Review Sprint 2 Summary (Model Development)
3. Review Sprint 6 Summary (Deployment)
4. Consult Technical Documentation (NASA SE standards)

---

**Package Version:** 1.0
**Last Updated:** 2025-11-19
